/**
*********************************************************************************************************
*                                            bh67f2472
*                                      (c) Copyright 2025-2035
*                                         All Rights Reserved
*
* @File    : 
* @By      : liwei
* @Version : V0.01
* 
*********************************************************************************************************
**/

/*
*********************************************************************************************************
Includes 
*********************************************************************************************************
*/
#include "string.h"
#include ".\scheduler.h"
#include "..\user_type.h"
#include "..\gpio_task\gpio_task.h"
#include "..\lcd_task\lcd_task.h"
#include "..\ntc_task\ntc_task.h"
/*
*********************************************************************************************************
Define
*********************************************************************************************************
*/


/*
*********************************************************************************************************
Typedef
*********************************************************************************************************
*/
//确保SCHEDULER_MAX在枚举中最后一个位置
typedef enum {
    SCHEDULER_LCD,
	SCHEDULER_GPIO,
	SCHEDULER_NTC,	
    SCHEDULER_MAX,	
} scheduler_def;

/* timer0 寄存器定义*/
#include "BH67F2472.h"
 typedef enum {
    TIMER_COMPARE_MATCH_OUTPUT    = (0x00 << 6),
    TIMER_CAPTURE_INPUT           = (0x01 << 6),
    TIMER_PWM_SINGLE_PULSE_OUTPUT = (0x02 << 6),
    TIMER_TIMER_COUNTER           = (0x03 << 6),
} TimerModeCfg_t;  
 typedef enum {
    STM_CLOCK_FSYS_4   = (0x00 << 4),
    STM_CLOCK_FSYS     = (0x01 << 4),
    STM_CLOCK_FH_16    = (0x02 << 4),
    STM_CLOCK_FH_64    = (0x03 << 4),
    STM_CLOCK_FSUB     = (0x04 << 4),
    STM_CLOCK_PIN_RISE = (0x06 << 4),
    STM_CLOCK_PIN_FALL = (0x07 << 4),
} STM_Clock_e;

/*! STM count clear mode enum */
typedef enum {
    STM_COUNT_CLEAR_P_MATCH,
    STM_COUNT_CLEAR_A_MATCH,
} STM_CountClear_e;
#define STM_Enable()           { _stpau = 0;  _ston = 1;}
#define STM_Disable()          { _ston = 0;}
#define STMA_Isr_Enable()      { _stmaf = 0; _stmae =1; _mf1e = 1;}
#define STMA_Isr_Disable()     { _stmae = 0;}
#define SET_TMn_CLOCK(n, type)          { _stmc0 &= 0x8F; _stmc0 |= type;}
#define SET_TMn_MODE(n, type)           { _stmc1 &= 0x3F; _stmc1 |= type;}
#define SET_TMn_CCRA(n,x)               { _stmal = x%256; _stmah = x/256;}
#define SET_TMn_COUNT_CLEAR(n,type)     {_stcclr = type;}
/* timer0 寄存器定义*/
/*
*********************************************************************************************************
Variables
*********************************************************************************************************
*/

uint8_t scheduler_stream[10];

/*
*********************************************************************************************************
Function 
*********************************************************************************************************
*/
/********************************************************************************************************
定时器中断
********************************************************************************************************/
DEFINE_ISR(STM_ISR, 0x14)
{
	//依次调佣任务中断函数
    _stmaf = 0;
	gpio_task_interrput_callback();
	lcd_task_interrput_callback();
	ntc_task_interrput_callback();
}
/********************************************************************************************************
定时器配置
********************************************************************************************************/
void time0_initialization(void)
{
	// 配置定时器1MS中断
	SET_TMn_COUNT_CLEAR(0, STM_COUNT_CLEAR_A_MATCH);
	SET_TMn_MODE(0, TIMER_COMPARE_MATCH_OUTPUT);
	SET_TMn_CLOCK(0, STM_CLOCK_FSYS_4);
	SET_TMn_CCRA(0, 2000);

	//使能定时器
	STM_Enable();

	//使能定时器中断
	STMA_Isr_Enable();
	//开启中断
	_emi = 1;
}
/********************************************************************************************************
由于编译器不支持函数指针，使用状态机调用函数
********************************************************************************************************/
void scheduler_operation(uint8_t scheduler ,uint8_t cmd ,uint8_t* stream)
{
	switch(scheduler)
	{
		//执行LCD任务
		case SCHEDULER_LCD:
			lcd_task_operation(cmd ,stream); 
		break;
		//执行GPIO任务
		case SCHEDULER_GPIO:
			gpio_task_operation(cmd ,stream); 
		break;		
		//执行温度测量任务
		case SCHEDULER_NTC:
			ntc_task_operation(cmd ,stream); 
		break;		
		default:
		break;			
	}
};
/********************************************************************************************************
将调度器中的任务进行初始化
********************************************************************************************************/
void scheduler_initialization(void)
{
	uint8_t	i = 0;
	//设置一个1MS定时器	
	time0_initialization();
	//依次执行所有任务的初始化操作
	for(i = 0 ; i < SCHEDULER_MAX ; i++)
	{
		scheduler_operation(i ,OPERATION_INITALIZTION ,null_stream);		
	}
}
/********************************************************************************************************
运行调度器中的任务
********************************************************************************************************/
void scheduler_run(void)
{
	uint8_t	i = 0;
	//依次执行所有任务
	for(i = 0 ; i < SCHEDULER_MAX ; i++)
	{
		scheduler_operation(i ,OPERATION_RUN ,null_stream);		
	}
}
/********************************************************************************************************
执行任务中的读写交互，所有任务依次执行read write
********************************************************************************************************/	
uint8_t trigger_scheduler(void)
{
	uint8_t i,j;
	/* */
	for(i =0; i < SCHEDULER_MAX; i++)
	{
		/* 执行读取操作*/
		scheduler_operation(i , OPERATION_READ , scheduler_stream);
		/*依次写入其他任务 */
		for(j =0; j < SCHEDULER_MAX; j++)
		{
			/* 排除自身*/
			if(i != j)
				scheduler_operation(j ,OPERATION_WRITE ,scheduler_stream);	
		}
		/*清空数据 */
		memset(scheduler_stream,0,sizeof(scheduler_stream));
	}	
	return 0;
}
/********************************************************************************************************
运行调度器中的任务
********************************************************************************************************/	
void user_scheduler(void)
{
	/* 执行任务读写交互*/
	trigger_scheduler();
	/*依次执行任务后台run函数*/
	scheduler_run();
}
/***********************************************END*****************************************************/