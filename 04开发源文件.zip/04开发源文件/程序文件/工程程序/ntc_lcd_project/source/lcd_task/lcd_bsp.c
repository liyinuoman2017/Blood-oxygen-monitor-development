/**
*********************************************************************************************************
*                                            bh67f2472
*                                      (c) Copyright 2025-2035
*                                         All Rights Reserved
*
* @File    : 
* @By      : liwei
* @Version : V0.01
* 
*********************************************************************************************************
**/

/*
*********************************************************************************************************
Includes 
*********************************************************************************************************
*/
#include "BH67F2472.h"
#include "..\user_type.h"
/*
*********************************************************************************************************
Define
*********************************************************************************************************
*/
#define PIN_PD0_SEG0()      { _pds01 = 1; _pds00 = 1;}
#define PIN_PD1_SEG1()      { _pds03 = 1; _pds02 = 1;}
#define PIN_PD2_SEG2()      { _pds05 = 1; _pds04 = 1;}
#define PIN_PD3_SEG3()      { _pds07 = 1; _pds06 = 1;}
#define PIN_PD4_SEG4()      { _pds11 = 1; _pds10 = 1;}
#define PIN_PD5_SEG5()      { _pds13 = 1; _pds12 = 1;}
#define PIN_PD6_SEG6()      { _pds15 = 1; _pds14 = 1;}
#define PIN_PD7_SEG7()      { _pds17 = 1; _pds16 = 1;}
#define PIN_PE0_SEG8()      { _pes01 = 1; _pes00 = 1;}

#define Lcd_Enable()      { _lcden = 0x01;}
#define Lcd_Disable()     { _lcden = 0x00;}

/*
*********************************************************************************************************
Typedef
*********************************************************************************************************
*/

typedef enum {
    LCD_WAVEFORM_TYPE_A = (0x00 << 7),
    LCD_WAVEFORM_TYPE_B = (0x01 << 7),
} Lcd_WaveForm_e;

/*! Lcd duty Selection enum */
typedef enum {
    LCD_DUTY_4COM = (0x00 << 1),
    LCD_DUTY_6COM = (0x01 << 1),
    LCD_DUTY_8COM = (0x02 << 1), //!< R type only
} Lcd_Duty_e;


/*! Lcd C type Power Selection enum */
typedef enum {
    LCD_CTYPE_POWER_PLCD_V1_V2 = (0x00 << 4), //*!< power from: plcd or v1 or v2
    LCD_CTYPE_POWER_VC         = (0x01 << 4), //*!< power from: Vc
    LCD_CTYPE_POWER_VB         = (0x02 << 4), //*!< power from: Vb=3V
    LCD_CTYPE_POWER_VDD        = (0x03 << 4), //*!< power from: Va=VDD
} Lcd_CType_Power_e;

/*! Lcd C type Pump Clock Selection enum */
typedef enum {
    LCD_CTYPE_Clock_250HZ = (0x00 << 5),
    LCD_CTYPE_Clock_500HZ = (0x01 << 5),
    LCD_CTYPE_Clock_1KHZ  = (0x02 << 5),
    LCD_CTYPE_Clock_2KHZ  = (0x03 << 5),
    LCD_CTYPE_Clock_4KHZ  = (0x04 << 5),
    LCD_CTYPE_Clock_8KHZ  = (0x05 << 5),
    LCD_CTYPE_Clock_16KHZ = (0x06 << 5),
} Lcd_Ctype_Clock_e;

/*! Lcd R type Power Selection enum */
typedef enum {
    LCD_RTYPE_POWER_PLCD = 0x00, //*!< power from: plcd
    LCD_RTYPE_POWER_3V3  = 0x08, //*!< power from internal charge pump:3.3V
    LCD_RTYPE_POWER_3V0  = 0x09, //*!< power from internal charge pump:3.0V
    LCD_RTYPE_POWER_2V7  = 0x0A, //*!< power from internal charge pump:2.7V
    LCD_RTYPE_POWER_4V5  = 0x0B, //*!< power from internal charge pump:4.5V
} Lcd_Rtype_Power_e;

/*! Lcd R type Bias Current Selection enum */
typedef enum {
    LCD_RTYPE_BIAS_CURRENT_25UA  = (0x00 << 1),
    LCD_RTYPE_BIAS_CURRENT_50UA  = (0x01 << 1),
    LCD_RTYPE_BIAS_CURRENT_100UA = (0x02 << 1),
    LCD_RTYPE_BIAS_CURRENT_200UA = (0x03 << 1),
} Lcd_Rtype_BiasCurrent_e;

typedef enum {
    LCD_TYPE_R = (0x00 << 6),
    LCD_TYPE_C = (0x01 << 6),
} Lcd_Type_e;
/*
*********************************************************************************************************
Variables
*********************************************************************************************************
*/
uint8_t data0,data1,data2,data3,data4,data5,data6,data7,data8;


/*
*********************************************************************************************************
Function 
*********************************************************************************************************
*/



/********************************************************************************************************
LCD模块初始化
********************************************************************************************************/
static void initialization(uint8_t*stream)
{
	//初始化SEG引脚
	PIN_PD1_SEG1() ;
	PIN_PD2_SEG2() ;
	PIN_PD3_SEG3() ;
	PIN_PD4_SEG4() ;
	PIN_PD5_SEG5() ;
	PIN_PD6_SEG6() ;
	PIN_PD7_SEG7() ;	
	PIN_PE0_SEG8() ;
	
	//初始化LCD模块
    _lcdc0 = LCD_TYPE_C + LCD_WAVEFORM_TYPE_B + LCD_CTYPE_POWER_VC;
    _lcdc2 = LCD_CTYPE_Clock_8KHZ + LCD_DUTY_4COM;
	//使能LCD
	Lcd_Enable() ;	
}
/********************************************************************************************************
写入LCD显示寄存器，LCD寄存器操作特殊，不支持数组
********************************************************************************************************/
void lcd_write_register(void)
{
	//显示寄存器从0x4000开始，连续0x32个显示字节，本项目运用了1~8
	_mp1h = 4;
	_mp1l = 0x00;

	_iar1 = data0;
	_mp1l++;
	_iar1 = data1;
	_mp1l++;
	_iar1 = data2;
	_mp1l++;
	_iar1 = data3;
	_mp1l++;
	_iar1 = data4;
	_mp1l++;
	_iar1 = data5;
	_mp1l++;
	_iar1 = data6;
	_mp1l++;
	_iar1 = data7;
	_mp1l++;
	_iar1 = data8;
	_mp1l++;	
}
/********************************************************************************************************
读操作，其他对象可以通过读取操作获取本对象的信息
********************************************************************************************************/
static void read(uint8_t*stream)
{
	
}
/********************************************************************************************************
写入LCD数据缓存，LCD寄存器操作特殊，不支持数组
********************************************************************************************************/
static void write(uint8_t*stream)
{
	data0 = stream[0];
	data1 = stream[1];
	data2 = stream[2];
	data3 = stream[3];
	data4 = stream[4];
	data5 = stream[5];
	data6 = stream[6];	
	data7 = stream[7];	
	data8 = stream[8];	
	//写入LCD显示寄存器
	lcd_write_register();	
}	
/********************************************************************************************************
后台连续运行
********************************************************************************************************/
static void run(uint8_t*stream)
{
	
}
/********************************************************************************************************
LCD BSP级操作对象,由于编译器不支持函数指针，使用状态机调用函数
********************************************************************************************************/
void lcd_bsp_operation(uint8_t cmd ,uint8_t*stream)
{
	switch(cmd)
	{
		case OPERATION_READ:
			read(stream);
		break;
		case OPERATION_WRITE:
			write(stream);
		break;
		case OPERATION_INITALIZTION:
			initialization(stream);
		break;
		case OPERATION_RUN:
			run(stream);
		break;	
		default:
		break;			
	}
};
/***********************************************END*****************************************************/