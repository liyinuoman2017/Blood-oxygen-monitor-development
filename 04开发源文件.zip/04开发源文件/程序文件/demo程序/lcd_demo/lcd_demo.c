/**
*********************************************************************************************************
*                                            bh67f2472
*                                      (c) Copyright 2025-2035
*                                         All Rights Reserved
*
* @File    : 
* @By      : liwei
* @Version : V0.01
* 
*********************************************************************************************************
**/

/*
*********************************************************************************************************
Includes 
*********************************************************************************************************
*/
#include "BH67F2472.h"
#include "string.h"

/*
*********************************************************************************************************
Define
*********************************************************************************************************
*/
#define PIN_PD0_SEG0()      { _pds01 = 1; _pds00 = 1;}
#define PIN_PD1_SEG1()      { _pds03 = 1; _pds02 = 1;}
#define PIN_PD2_SEG2()      { _pds05 = 1; _pds04 = 1;}
#define PIN_PD3_SEG3()      { _pds07 = 1; _pds06 = 1;}
#define PIN_PD4_SEG4()      { _pds11 = 1; _pds10 = 1;}
#define PIN_PD5_SEG5()      { _pds13 = 1; _pds12 = 1;}
#define PIN_PD6_SEG6()      { _pds15 = 1; _pds14 = 1;}
#define PIN_PD7_SEG7()      { _pds17 = 1; _pds16 = 1;}
#define PIN_PE0_SEG8()      { _pes01 = 1; _pes00 = 1;}

#define Lcd_Enable()      { _lcden = 0x01;}
#define Lcd_Disable()     { _lcden = 0x00;}

/*
*********************************************************************************************************
Typedef
*********************************************************************************************************
*/

typedef enum {
    LCD_WAVEFORM_TYPE_A = (0x00 << 7),
    LCD_WAVEFORM_TYPE_B = (0x01 << 7),
} Lcd_WaveForm_e;

/*! Lcd duty Selection enum */
typedef enum {
    LCD_DUTY_4COM = (0x00 << 1),
    LCD_DUTY_6COM = (0x01 << 1),
    LCD_DUTY_8COM = (0x02 << 1), //!< R type only
} Lcd_Duty_e;


/*! Lcd C type Power Selection enum */
typedef enum {
    LCD_CTYPE_POWER_PLCD_V1_V2 = (0x00 << 4), //*!< power from: plcd or v1 or v2
    LCD_CTYPE_POWER_VC         = (0x01 << 4), //*!< power from: Vc
    LCD_CTYPE_POWER_VB         = (0x02 << 4), //*!< power from: Vb=3V
    LCD_CTYPE_POWER_VDD        = (0x03 << 4), //*!< power from: Va=VDD
} Lcd_CType_Power_e;

/*! Lcd C type Pump Clock Selection enum */
typedef enum {
    LCD_CTYPE_Clock_250HZ = (0x00 << 5),
    LCD_CTYPE_Clock_500HZ = (0x01 << 5),
    LCD_CTYPE_Clock_1KHZ  = (0x02 << 5),
    LCD_CTYPE_Clock_2KHZ  = (0x03 << 5),
    LCD_CTYPE_Clock_4KHZ  = (0x04 << 5),
    LCD_CTYPE_Clock_8KHZ  = (0x05 << 5),
    LCD_CTYPE_Clock_16KHZ = (0x06 << 5),
} Lcd_Ctype_Clock_e;

/*! Lcd R type Power Selection enum */
typedef enum {
    LCD_RTYPE_POWER_PLCD = 0x00, //*!< power from: plcd
    LCD_RTYPE_POWER_3V3  = 0x08, //*!< power from internal charge pump:3.3V
    LCD_RTYPE_POWER_3V0  = 0x09, //*!< power from internal charge pump:3.0V
    LCD_RTYPE_POWER_2V7  = 0x0A, //*!< power from internal charge pump:2.7V
    LCD_RTYPE_POWER_4V5  = 0x0B, //*!< power from internal charge pump:4.5V
} Lcd_Rtype_Power_e;

/*! Lcd R type Bias Current Selection enum */
typedef enum {
    LCD_RTYPE_BIAS_CURRENT_25UA  = (0x00 << 1),
    LCD_RTYPE_BIAS_CURRENT_50UA  = (0x01 << 1),
    LCD_RTYPE_BIAS_CURRENT_100UA = (0x02 << 1),
    LCD_RTYPE_BIAS_CURRENT_200UA = (0x03 << 1),
} Lcd_Rtype_BiasCurrent_e;

typedef enum {
    LCD_TYPE_R = (0x00 << 6),
    LCD_TYPE_C = (0x01 << 6),
} Lcd_Type_e;
/*
*********************************************************************************************************
Variables
*********************************************************************************************************
*/

char char_buff[10] ;
char uart_buff[20] ="adc:";
unsigned int adc_date;


/*
*********************************************************************************************************
Function 
*********************************************************************************************************
*/



/********************************************************************************************************
 延时函数 单位为ms
********************************************************************************************************/
void delay_ms(unsigned long int ms)
{
	while(ms--)
		GCC_DELAY(2000);//主频8Mhz，执行一条指令为0.5us。一条指令周期等于四条机器周期——》 1/8Mhz * 4 = 0.5us
}
/********************************************************************************************************
串口配置
********************************************************************************************************/
void uart0_initialization(void)
{
	//UART0 TX RX引脚设置
	_pcs15 = 0; _pcs14 = 1;
	_pcs01 = 0; _pcs00 = 1;
	_u0md=1;
	//UART0 设置波特率9600
	_u0brg= 0x0c; 
	//8位数据 
	_u0usr = 0x20;	
	_u0usr &= 0xFC; 
	_u0usr |= 0x01;
	_u0swm = 0;

	//UART0使能
	_ur0en = 1; 
	_u0txen = 1; 
	_u0rxen = 1;
}
/********************************************************************************************************
LCD模块初始化
********************************************************************************************************/
void lcd_initialization(void)
{
	//初始化SEG引脚
	PIN_PD0_SEG0() ;
	PIN_PD1_SEG1() ;
	PIN_PD2_SEG2() ;
	PIN_PD3_SEG3() ;
	PIN_PD4_SEG4() ;
	PIN_PD5_SEG5() ;
	PIN_PD6_SEG6() ;
	PIN_PD7_SEG7() ;	
	PIN_PE0_SEG8() ;
	
	//初始化LCD模块
    _lcdc0 = LCD_TYPE_C + LCD_WAVEFORM_TYPE_B + LCD_CTYPE_POWER_VC;
    _lcdc2 = LCD_CTYPE_Clock_8KHZ + LCD_DUTY_4COM;
	//使能LCD
	Lcd_Enable() ;
	
}
/********************************************************************************************************
串口输出
********************************************************************************************************/
void uart0_send(unsigned char *buff, unsigned char len)
{
    unsigned char i;
    for (i = 0; i < len; i++)
    {
        _u0txr_rxr = *buff;
		//等待发送完成
        while (!_u0tidle);
        buff++;
    }
}
/********************************************************************************************************
数值转字符串
********************************************************************************************************/
void value_to_string(unsigned int value ,unsigned char lenght,char* buff)
{
	unsigned char i;
	unsigned int divisor = 1;
	for(i = 0 ; i < lenght ; i++)	
	{
		buff[lenght - 1 - i] = 	0x30 + value/divisor%10;
		divisor = divisor*10;	
	}
}
/********************************************************************************************************
时钟配置
********************************************************************************************************/
void oscillators_initialization(void)
{
	//选择内部时钟
	_fhs = 0;
	//系统时钟设置为8000000
	_hircc = 0x05;	
	// Wait HIRC Oscillator Stable
	while (!_hircf);    
}
/********************************************************************************************************
LCD所有段显示
********************************************************************************************************/
void lcd_all_on()
{
    _mp1h = 4;
    _mp1l = 0x00;
    for (_tblp = 0x00; _tblp <= 36; _tblp++)
    {
        _iar1 = 0xFF;
        _mp1l++;
    }
}
/********************************************************************************************************
LCD所有段不显示
********************************************************************************************************/
void lcd_all_off()
{
    _mp1h = 4;
    _mp1l = 0x00;
    for (_tblp = 0x00; _tblp <= 36; _tblp++)
    {
        _iar1 = 0x00;
        _mp1l++;
    }
}
/********************************************************************************************************
主函数
********************************************************************************************************/
void main(void)
{
	//配置系统时钟
	oscillators_initialization();
	//关闭看门狗
	_wdtc = 0b10101000;	

	//设置lcd
	lcd_initialization(); 

	while(1)
	{ 
	
		lcd_all_on();
		delay_ms(1000);
		
		lcd_all_off();
		delay_ms(1000);		

	}
}
/***********************************************END*****************************************************/